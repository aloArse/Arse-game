// ---------- Detailed articulated 3D superhero rig (fully procedural) ----------
// Convention: character faces +Z. Limb pivots hang along -Y.
// joint.rotation.x negative => limb swings FORWARD (+Z); -PI => straight overhead.
import * as THREE from "three";

export type JointName =
  | "spine" | "chest" | "neck" | "head"
  | "shL" | "elL" | "shR" | "elR"
  | "hipL" | "kneeL" | "hipR" | "kneeR";

export type Pose = Partial<Record<JointName, [number, number, number]>>;

export interface Palette {
  suit: number;
  suitDark: number;
  accent: number;
  accentDark: number;
  skin: number;
  eye: number;
  hair?: number;
  cape?: number;
  capeInner?: number;
  mustache?: boolean;
  masked?: boolean;
}

export const HERO_PAL: Palette = {
  suit: 0x2a5fe0, suitDark: 0x14307e, accent: 0xffd23f, accentDark: 0xc9991c,
  skin: 0xf3b389, eye: 0xffffff, masked: true,
};

export const BOSS_PAL: Palette = {
  suit: 0xf4f5fa, suitDark: 0xc0c5d6, accent: 0xd32436, accentDark: 0x8e121f,
  skin: 0xe8ab80, eye: 0xffe27a,
  hair: 0xf8f8fc, cape: 0xc01a2c, capeInner: 0x6d0d18,
  mustache: true, masked: false,
};

/* ---------------- pose library ---------------- */

export const POSES: Record<string, Pose> = {
  idle: {
    spine: [0.03, 0, 0], chest: [0.02, 0, 0], neck: [0, 0, 0], head: [0, 0, 0],
    shL: [-0.1, 0, 0.19], elL: [-0.26, 0, 0.04],
    shR: [-0.1, 0, -0.19], elR: [-0.26, 0, -0.04],
    hipL: [0.05, 0, 0.07], kneeL: [0.14, 0, 0],
    hipR: [0.05, 0, -0.07], kneeR: [0.14, 0, 0],
  },
  hover: {
    spine: [-0.07, 0, 0], chest: [0.05, 0, 0], neck: [0.03, 0, 0], head: [0.05, 0, 0],
    shL: [-0.36, 0.12, 0.34], elL: [-0.66, 0, 0.12],
    shR: [-0.36, -0.12, -0.34], elR: [-0.66, 0, -0.12],
    hipL: [0.32, 0, 0.11], kneeL: [0.6, 0, 0],
    hipR: [0.19, 0, -0.11], kneeR: [0.38, 0, 0],
  },
  fly: {
    spine: [0.05, 0, 0], chest: [-0.02, 0, 0], neck: [-0.16, 0, 0], head: [-0.2, 0, 0],
    shL: [-2.88, 0.14, 0.14], elL: [-0.07, 0, 0],
    shR: [-2.88, -0.14, -0.14], elR: [-0.07, 0, 0],
    hipL: [0.13, 0, 0.05], kneeL: [0.1, 0, 0],
    hipR: [0.09, 0, -0.05], kneeR: [0.14, 0, 0],
  },
  fist: {
    spine: [0.06, 0, 0.05], chest: [-0.02, 0.12, 0], neck: [-0.16, -0.05, 0], head: [-0.2, -0.06, 0],
    shL: [0.46, 0.12, 0.22], elL: [-0.34, 0, 0.05],
    shR: [-2.96, -0.1, -0.12], elR: [-0.04, 0, 0],
    hipL: [0.17, 0, 0.06], kneeL: [0.19, 0, 0],
    hipR: [0.07, 0, -0.06], kneeR: [0.09, 0, 0],
  },
  dash: {
    spine: [0.09, 0, 0], chest: [0.02, 0, 0], neck: [-0.14, 0, 0], head: [-0.18, 0, 0],
    shL: [0.58, 0.04, 0.12], elL: [-0.54, 0, 0.04],
    shR: [0.58, -0.04, -0.12], elR: [-0.54, 0, -0.04],
    hipL: [0.05, 0, 0.04], kneeL: [0.07, 0, 0],
    hipR: [0.05, 0, -0.04], kneeR: [0.07, 0, 0],
  },
  // --- 3-hit strike chain ---
  punch: {
    spine: [-0.08, -0.38, 0], chest: [0.02, -0.24, 0], neck: [0, 0.16, 0], head: [-0.05, 0.22, 0],
    shL: [1.0, 0.22, 0.2], elL: [-1.16, 0, 0],
    shR: [-1.66, -0.1, -0.08], elR: [-0.05, 0, 0],
    hipL: [-0.36, 0, 0.12], kneeL: [0.52, 0, 0],
    hipR: [0.46, 0, -0.12], kneeR: [0.3, 0, 0],
  },
  punchAlt: {
    spine: [-0.08, 0.38, 0], chest: [0.02, 0.24, 0], neck: [0, -0.16, 0], head: [-0.05, -0.22, 0],
    shL: [-1.66, 0.1, 0.08], elL: [-0.05, 0, 0],
    shR: [1.0, -0.22, -0.2], elR: [-1.16, 0, 0],
    hipL: [0.46, 0, 0.12], kneeL: [0.3, 0, 0],
    hipR: [-0.36, 0, -0.12], kneeR: [0.52, 0, 0],
  },
  uppercut: {
    spine: [-0.34, -0.16, 0], chest: [-0.2, -0.1, 0], neck: [-0.2, 0.08, 0], head: [-0.3, 0.1, 0],
    shL: [-2.5, 0.3, 0.2], elL: [-0.5, 0, 0],
    shR: [0.7, -0.2, -0.3], elR: [-0.9, 0, 0],
    hipL: [-0.2, 0, 0.14], kneeL: [0.4, 0, 0],
    hipR: [0.3, 0, -0.14], kneeR: [0.9, 0, 0],
  },
  clap: {
    spine: [-0.12, 0, 0], chest: [0.06, 0, 0], neck: [-0.06, 0, 0], head: [-0.08, 0, 0],
    shL: [-1.5, 0.72, 0.1], elL: [-0.34, 0, 0],
    shR: [-1.5, -0.72, -0.1], elR: [-0.34, 0, 0],
    hipL: [0.3, 0, 0.12], kneeL: [0.44, 0, 0],
    hipR: [0.3, 0, -0.12], kneeR: [0.44, 0, 0],
  },
  clapWind: {
    spine: [0.12, 0, 0], chest: [-0.06, 0, 0], neck: [0.04, 0, 0], head: [0.06, 0, 0],
    shL: [-1.2, -0.95, 0.9], elL: [-0.9, 0, 0],
    shR: [-1.2, 0.95, -0.9], elR: [-0.9, 0, 0],
    hipL: [0.26, 0, 0.12], kneeL: [0.42, 0, 0],
    hipR: [0.26, 0, -0.12], kneeR: [0.42, 0, 0],
  },
  grab: {
    spine: [-0.06, 0, 0], chest: [0.04, 0, 0], neck: [-0.05, 0, 0], head: [-0.08, 0, 0],
    shL: [-1.72, 0.26, 0.2], elL: [-0.34, 0, 0],
    shR: [-1.72, -0.26, -0.2], elR: [-0.34, 0, 0],
    hipL: [0.26, 0, 0.12], kneeL: [0.44, 0, 0],
    hipR: [0.26, 0, -0.12], kneeR: [0.44, 0, 0],
  },
  throw: {
    spine: [0.3, -0.22, 0], chest: [0.16, -0.14, 0], neck: [0.12, 0.1, 0], head: [0.16, 0.12, 0],
    shL: [-1.1, 0.2, 0.24], elL: [-0.2, 0, 0],
    shR: [-1.1, -0.2, -0.24], elR: [-0.2, 0, 0],
    hipL: [0.2, 0, 0.12], kneeL: [0.5, 0, 0],
    hipR: [0.2, 0, -0.12], kneeR: [0.5, 0, 0],
  },
  blast: {
    spine: [-0.13, 0, 0], chest: [0.09, 0, 0], neck: [-0.06, 0, 0], head: [-0.08, 0, 0],
    shL: [-1.46, 0.22, 0.24], elL: [-0.18, 0, 0],
    shR: [-1.46, -0.22, -0.24], elR: [-0.18, 0, 0],
    hipL: [0.29, 0, 0.13], kneeL: [0.44, 0, 0],
    hipR: [0.21, 0, -0.13], kneeR: [0.32, 0, 0],
  },
  slamUp: {
    spine: [-0.36, 0, 0], chest: [-0.18, 0, 0], neck: [-0.2, 0, 0], head: [-0.3, 0, 0],
    shL: [-2.96, 0.22, 0.36], elL: [-0.28, 0, 0],
    shR: [-2.96, -0.22, -0.36], elR: [-0.28, 0, 0],
    hipL: [0.52, 0, 0.17], kneeL: [0.95, 0, 0],
    hipR: [0.52, 0, -0.17], kneeR: [0.95, 0, 0],
  },
  slamDown: {
    spine: [0.42, 0, 0], chest: [0.22, 0, 0], neck: [0.16, 0, 0], head: [0.26, 0, 0],
    shL: [-0.4, 0.12, 0.16], elL: [-0.2, 0, 0],
    shR: [-0.4, -0.12, -0.16], elR: [-0.2, 0, 0],
    hipL: [0.48, 0, 0.2], kneeL: [0.6, 0, 0],
    hipR: [0.48, 0, -0.2], kneeR: [0.6, 0, 0],
  },
  hurt: {
    spine: [-0.32, 0.14, 0], chest: [-0.16, 0, 0], neck: [-0.22, 0, 0], head: [-0.34, 0, 0],
    shL: [-0.95, 0.55, 0.75], elL: [-1.25, 0, 0],
    shR: [-0.95, -0.55, -0.75], elR: [-1.25, 0, 0],
    hipL: [-0.3, 0, 0.25], kneeL: [0.82, 0, 0],
    hipR: [-0.2, 0, -0.25], kneeR: [0.72, 0, 0],
  },
};

/* ---------------- geometry helpers ---------------- */

function torsoGeometry(): THREE.BufferGeometry {
  // V-taper profile revolved, then flattened front-to-back
  const pts: THREE.Vector2[] = [
    new THREE.Vector2(0.001, -0.05),
    new THREE.Vector2(0.175, -0.045),
    new THREE.Vector2(0.205, 0.02),
    new THREE.Vector2(0.204, 0.10),
    new THREE.Vector2(0.193, 0.19),
    new THREE.Vector2(0.194, 0.28),
    new THREE.Vector2(0.213, 0.37),
    new THREE.Vector2(0.243, 0.455),
    new THREE.Vector2(0.259, 0.525),
    new THREE.Vector2(0.249, 0.585),
    new THREE.Vector2(0.206, 0.639),
    new THREE.Vector2(0.135, 0.678),
    new THREE.Vector2(0.082, 0.7),
    new THREE.Vector2(0.001, 0.706),
  ];
  const g = new THREE.LatheGeometry(pts, 26);
  g.scale(1, 1, 0.79);
  g.computeVertexNormals();
  return g;
}

function pelvisGeometry(): THREE.BufferGeometry {
  const pts: THREE.Vector2[] = [
    new THREE.Vector2(0.001, -0.2),
    new THREE.Vector2(0.11, -0.19),
    new THREE.Vector2(0.168, -0.13),
    new THREE.Vector2(0.196, -0.05),
    new THREE.Vector2(0.203, 0.02),
    new THREE.Vector2(0.001, 0.04),
  ];
  const g = new THREE.LatheGeometry(pts, 22);
  g.scale(1, 1, 0.8);
  g.computeVertexNormals();
  return g;
}

/* ---------------- rig ---------------- */

export class Rig {
  group = new THREE.Group();
  body = new THREE.Group();
  joints = {} as Record<JointName, THREE.Group>;
  fistL = new THREE.Object3D();
  fistR = new THREE.Object3D();
  chestAnchor = new THREE.Object3D();
  cape: THREE.Group | null = null;

  private capeSegs: THREE.Group[] = [];
  private capeAng: number[] = [];
  private mats: THREE.Material[] = [];
  private geos: THREE.BufferGeometry[] = [];
  private eyeMat!: THREE.MeshStandardMaterial;
  private auraMat: THREE.MeshBasicMaterial | null = null;
  private aura: THREE.Mesh | null = null;
  private bicepL!: THREE.Mesh;
  private bicepR!: THREE.Mesh;
  private pecL!: THREE.Mesh;
  private pecR!: THREE.Mesh;
  private chestMesh!: THREE.Mesh;
  private flex = 0;
  private breath = 0;

  constructor(pal: Palette, scale = 1) {
    const mk = (color: number, o: Partial<THREE.MeshPhysicalMaterialParameters> = {}) => {
      const m = new THREE.MeshPhysicalMaterial({
        color, roughness: 0.46, metalness: 0.08,
        clearcoat: 0.55, clearcoatRoughness: 0.38, ...o,
      });
      this.mats.push(m);
      return m;
    };
    const keep = <T extends THREE.BufferGeometry>(g: T): T => { this.geos.push(g); return g; };

    const suit = mk(pal.suit);
    const suitDark = mk(pal.suitDark, { roughness: 0.55, clearcoat: 0.3 });
    const accent = mk(pal.accent, { roughness: 0.3, metalness: 0.3, clearcoat: 0.8 });
    const accentDark = mk(pal.accentDark, { roughness: 0.42, metalness: 0.25 });
    const skin = mk(pal.skin, { roughness: 0.72, metalness: 0.0, clearcoat: 0.15 });

    this.eyeMat = new THREE.MeshStandardMaterial({
      color: pal.eye, emissive: new THREE.Color(pal.eye),
      emissiveIntensity: 1.4, roughness: 0.18, metalness: 0.1,
    });
    this.mats.push(this.eyeMat);

    const capsule = (r: number, len: number, caps = 5, seg = 12) =>
      keep(new THREE.CapsuleGeometry(r, Math.max(0.01, len - r * 2), caps, seg));
    const sphere = (r: number, w = 14, h = 10) => keep(new THREE.SphereGeometry(r, w, h));

    this.group.add(this.body);

    // ================= torso =================
    const spine = new THREE.Group();
    this.joints.spine = spine;
    this.body.add(spine);

    const pelvis = new THREE.Mesh(keep(pelvisGeometry()), suitDark);
    spine.add(pelvis);

    const chest = new THREE.Group();
    chest.position.y = 0.06;
    this.joints.chest = chest;
    spine.add(chest);

    this.chestMesh = new THREE.Mesh(keep(torsoGeometry()), suit);
    chest.add(this.chestMesh);
    chest.add(this.chestAnchor);
    this.chestAnchor.position.set(0, 0.45, 0.24);

    // pectorals
    for (const sx of [-1, 1]) {
      const pec = new THREE.Mesh(sphere(0.105), suit);
      pec.position.set(sx * 0.088, 0.5, 0.125);
      pec.scale.set(1.15, 0.86, 0.72);
      chest.add(pec);
      if (sx < 0) this.pecL = pec; else this.pecR = pec;
    }
    // abdominals
    for (let row = 0; row < 3; row++) {
      for (const sx of [-1, 1]) {
        const ab = new THREE.Mesh(sphere(0.05, 10, 8), suit);
        ab.position.set(sx * 0.048, 0.395 - row * 0.082, 0.152 - row * 0.012);
        ab.scale.set(1, 0.82, 0.5);
        chest.add(ab);
      }
    }
    // obliques / lats
    for (const sx of [-1, 1]) {
      const lat = new THREE.Mesh(sphere(0.1), suit);
      lat.position.set(sx * 0.185, 0.43, -0.03);
      lat.scale.set(0.72, 1.3, 0.85);
      chest.add(lat);
    }
    // traps
    const trap = new THREE.Mesh(sphere(0.14), suit);
    trap.position.set(0, 0.6, -0.035);
    trap.scale.set(1.5, 0.62, 0.75);
    chest.add(trap);

    // belt
    const belt = new THREE.Mesh(keep(new THREE.CylinderGeometry(0.213, 0.208, 0.075, 24)), accent);
    belt.position.y = 0.045;
    belt.scale.z = 0.81;
    chest.add(belt);
    const buckle = new THREE.Mesh(keep(new THREE.BoxGeometry(0.1, 0.075, 0.04)), accentDark);
    buckle.position.set(0, 0.045, 0.168);
    chest.add(buckle);

    // chest chevron (two angled bars forming a V)
    for (const sx of [-1, 1]) {
      const bar = new THREE.Mesh(keep(new THREE.BoxGeometry(0.185, 0.045, 0.03)), accent);
      bar.position.set(sx * 0.072, 0.492, 0.192);
      bar.rotation.z = sx * -0.56;
      bar.rotation.x = -0.18;
      chest.add(bar);
    }

    // ================= head =================
    const neck = new THREE.Group();
    neck.position.y = 0.68;
    this.joints.neck = neck;
    chest.add(neck);
    const neckMesh = new THREE.Mesh(capsule(0.072, 0.14, 4, 10), pal.masked ? suit : skin);
    neckMesh.position.y = 0.03;
    neck.add(neckMesh);

    const head = new THREE.Group();
    head.position.y = 0.11;
    this.joints.head = head;
    neck.add(head);

    const skull = new THREE.Mesh(sphere(0.163, 20, 16), skin);
    skull.scale.set(0.95, 1.08, 1.02);
    skull.position.y = 0.035;
    head.add(skull);

    // jaw / chin
    const jaw = new THREE.Mesh(sphere(0.125, 16, 12), skin);
    jaw.position.set(0, -0.062, 0.022);
    jaw.scale.set(0.94, 0.8, 1.0);
    head.add(jaw);
    // mouth
    const mouth = new THREE.Mesh(keep(new THREE.BoxGeometry(0.062, 0.011, 0.02)), mk(0x7d4436, { roughness: 0.85, clearcoat: 0 }));
    mouth.position.set(0, -0.088, 0.138);
    head.add(mouth);

    if (pal.masked) {
      // ---- cowl: blue shell over the top/back of the head ----
      const cowl = new THREE.Mesh(
        keep(new THREE.SphereGeometry(0.176, 22, 18, 0, Math.PI * 2, 0, Math.PI * 0.58)),
        suit,
      );
      cowl.scale.set(0.99, 1.12, 1.05);
      cowl.position.y = 0.04;
      head.add(cowl);
      // back of cowl wraps lower
      const nape = new THREE.Mesh(
        keep(new THREE.SphereGeometry(0.172, 20, 16, 0, Math.PI * 2, Math.PI * 0.34, Math.PI * 0.34)),
        suit,
      );
      nape.scale.set(0.99, 1.1, 1.05);
      nape.position.set(0, 0.035, -0.028);
      nape.scale.z = 0.92;
      head.add(nape);

      // ---- yellow goggle band ----
      const band = new THREE.Mesh(keep(new THREE.TorusGeometry(0.152, 0.038, 10, 26, Math.PI * 1.16)), accent);
      band.rotation.set(Math.PI / 2, 0, Math.PI * 1.42);
      band.position.set(0, 0.028, 0.012);
      band.scale.set(1.06, 1.06, 0.92);
      head.add(band);
      // brow ridge above band
      const brow = new THREE.Mesh(keep(new THREE.TorusGeometry(0.156, 0.019, 8, 22, Math.PI * 0.86)), suitDark);
      brow.rotation.set(Math.PI / 2, 0, Math.PI * 1.28);
      brow.position.set(0, 0.082, 0.01);
      head.add(brow);

      // lenses
      for (const sx of [-1, 1]) {
        const lens = new THREE.Mesh(sphere(0.055, 14, 12), this.eyeMat);
        lens.position.set(sx * 0.073, 0.03, 0.132);
        lens.scale.set(1.2, 0.78, 0.42);
        lens.rotation.z = sx * 0.16;
        head.add(lens);
        // lens rim
        const rim = new THREE.Mesh(keep(new THREE.TorusGeometry(0.062, 0.012, 8, 16)), accentDark);
        rim.position.set(sx * 0.073, 0.03, 0.138);
        rim.scale.set(1.16, 0.8, 1);
        rim.rotation.z = sx * 0.16;
        head.add(rim);
      }
      // ear pods
      for (const sx of [-1, 1]) {
        const ear = new THREE.Mesh(capsule(0.032, 0.085, 4, 8), accent);
        ear.position.set(sx * 0.157, 0.015, -0.012);
        ear.rotation.z = Math.PI / 2;
        head.add(ear);
      }
    } else {
      // ---- villain: swept hair, brows, mustache ----
      const hairMat = mk(pal.hair ?? 0xffffff, { roughness: 0.68, clearcoat: 0.2 });
      const hair = new THREE.Mesh(
        keep(new THREE.SphereGeometry(0.178, 20, 16, 0, Math.PI * 2, 0, Math.PI * 0.56)),
        hairMat,
      );
      hair.scale.set(1.0, 1.1, 1.06);
      hair.position.y = 0.048;
      head.add(hair);
      // temple sweeps
      for (const sx of [-1, 1]) {
        const sweep = new THREE.Mesh(capsule(0.035, 0.16, 4, 8), hairMat);
        sweep.position.set(sx * 0.14, 0.045, -0.03);
        sweep.rotation.set(0.3, 0, sx * 0.42);
        head.add(sweep);
      }
      for (const sx of [-1, 1]) {
        const brow = new THREE.Mesh(capsule(0.017, 0.075, 3, 6), hairMat);
        brow.position.set(sx * 0.068, 0.062, 0.128);
        brow.rotation.set(0, 0, sx * 0.3 + Math.PI / 2);
        head.add(brow);
        const eye = new THREE.Mesh(sphere(0.032, 12, 10), this.eyeMat);
        eye.position.set(sx * 0.068, 0.022, 0.133);
        eye.scale.set(1.15, 0.85, 0.55);
        head.add(eye);
      }
      if (pal.mustache) {
        const mustMat = mk(0x2b2119, { roughness: 0.85, clearcoat: 0 });
        for (const sx of [-1, 1]) {
          const m = new THREE.Mesh(capsule(0.024, 0.1, 4, 8), mustMat);
          m.position.set(sx * 0.038, -0.072, 0.13);
          m.rotation.set(0.1, 0, Math.PI / 2 + sx * 0.22);
          head.add(m);
        }
      }
    }

    // ================= limbs =================
    const buildArm = (sx: number, shName: JointName, elName: JointName) => {
      const sh = new THREE.Group();
      sh.position.set(sx * 0.29, 0.56, 0);
      chest.add(sh);
      this.joints[shName] = sh;

      // deltoid
      const delt = new THREE.Mesh(sphere(0.115), suit);
      delt.scale.set(1.05, 1.12, 1.05);
      sh.add(delt);
      // shoulder trim ring
      const trim = new THREE.Mesh(keep(new THREE.TorusGeometry(0.104, 0.017, 8, 18)), accent);
      trim.rotation.x = Math.PI / 2;
      trim.position.y = -0.055;
      sh.add(trim);

      const upper = new THREE.Mesh(capsule(0.077, 0.335), suit);
      upper.position.y = -0.168;
      sh.add(upper);
      // bicep
      const bicep = new THREE.Mesh(sphere(0.084), suit);
      bicep.position.set(0, -0.135, 0.022);
      bicep.scale.set(1, 1.24, 1.02);
      sh.add(bicep);
      if (sx < 0) this.bicepL = bicep; else this.bicepR = bicep;
      // triceps
      const tri = new THREE.Mesh(sphere(0.072), suit);
      tri.position.set(0, -0.175, -0.032);
      tri.scale.set(0.92, 1.25, 0.85);
      sh.add(tri);

      const el = new THREE.Group();
      el.position.y = -0.335;
      sh.add(el);
      this.joints[elName] = el;

      const elbow = new THREE.Mesh(sphere(0.071, 12, 10), suitDark);
      el.add(elbow);
      const fore = new THREE.Mesh(capsule(0.066, 0.32), suit);
      fore.position.y = -0.16;
      fore.scale.set(1, 1, 1);
      el.add(fore);
      // forearm taper mass
      const brach = new THREE.Mesh(sphere(0.073), suit);
      brach.position.y = -0.105;
      brach.scale.set(1, 1.18, 1);
      el.add(brach);

      // ---- glove ----
      const cuff = new THREE.Mesh(keep(new THREE.CylinderGeometry(0.081, 0.073, 0.1, 14)), accent);
      cuff.position.y = -0.256;
      el.add(cuff);
      const cuffLip = new THREE.Mesh(keep(new THREE.TorusGeometry(0.082, 0.014, 8, 16)), accentDark);
      cuffLip.rotation.x = Math.PI / 2;
      cuffLip.position.y = -0.208;
      el.add(cuffLip);
      const hand = new THREE.Mesh(sphere(0.082, 14, 12), accent);
      hand.position.y = -0.338;
      hand.scale.set(0.95, 1.05, 1.1);
      el.add(hand);
      // knuckles
      for (let k = 0; k < 4; k++) {
        const kn = new THREE.Mesh(sphere(0.024, 8, 6), accentDark);
        kn.position.set((k - 1.5) * 0.032, -0.386, 0.052);
        el.add(kn);
      }
      // thumb
      const thumb = new THREE.Mesh(capsule(0.022, 0.062, 3, 6), accent);
      thumb.position.set(sx * 0.055, -0.352, 0.03);
      thumb.rotation.z = sx * 0.7;
      el.add(thumb);

      const anchor = sx < 0 ? this.fistL : this.fistR;
      anchor.position.y = -0.38;
      el.add(anchor);
    };

    const buildLeg = (sx: number, hipName: JointName, kneeName: JointName) => {
      const hip = new THREE.Group();
      hip.position.set(sx * 0.13, -0.14, 0);
      spine.add(hip);
      this.joints[hipName] = hip;

      const glute = new THREE.Mesh(sphere(0.115), suit);
      glute.position.set(0, -0.02, -0.035);
      glute.scale.set(1, 0.95, 1.05);
      hip.add(glute);

      const thigh = new THREE.Mesh(capsule(0.108, 0.42), suit);
      thigh.position.y = -0.21;
      hip.add(thigh);
      // quad
      const quad = new THREE.Mesh(sphere(0.112), suit);
      quad.position.set(0, -0.17, 0.026);
      quad.scale.set(1, 1.32, 1);
      hip.add(quad);

      const knee = new THREE.Group();
      knee.position.y = -0.42;
      hip.add(knee);
      this.joints[kneeName] = knee;

      const kneePad = new THREE.Mesh(sphere(0.094, 12, 10), suitDark);
      kneePad.scale.set(1, 0.95, 1.08);
      knee.add(kneePad);

      const shin = new THREE.Mesh(capsule(0.086, 0.4), suit);
      shin.position.y = -0.2;
      knee.add(shin);
      // calf
      const calf = new THREE.Mesh(sphere(0.09), suit);
      calf.position.set(0, -0.14, -0.032);
      calf.scale.set(0.92, 1.3, 0.9);
      knee.add(calf);

      // ---- boot ----
      const bootTop = new THREE.Mesh(keep(new THREE.CylinderGeometry(0.104, 0.098, 0.075, 14)), accentDark);
      bootTop.position.y = -0.238;
      knee.add(bootTop);
      const boot = new THREE.Mesh(capsule(0.097, 0.24, 4, 12), accent);
      boot.position.y = -0.33;
      knee.add(boot);
      // shin guard flare
      const guard = new THREE.Mesh(keep(new THREE.ConeGeometry(0.115, 0.14, 14, 1, true)), accent);
      guard.position.y = -0.262;
      guard.rotation.x = Math.PI;
      knee.add(guard);
      // foot
      const foot = new THREE.Mesh(keep(new THREE.BoxGeometry(0.125, 0.085, 0.255)), accent);
      foot.position.set(0, -0.418, 0.055);
      knee.add(foot);
      const toe = new THREE.Mesh(sphere(0.062, 12, 8), accent);
      toe.position.set(0, -0.418, 0.17);
      toe.scale.set(1, 0.72, 0.85);
      knee.add(toe);
      const sole = new THREE.Mesh(keep(new THREE.BoxGeometry(0.128, 0.028, 0.28)), suitDark);
      sole.position.set(0, -0.455, 0.06);
      knee.add(sole);
    };

    buildArm(-1, "shL", "elL");
    buildArm(1, "shR", "elR");
    buildLeg(-1, "hipL", "kneeL");
    buildLeg(1, "hipR", "kneeR");

    // ================= cape =================
    if (pal.cape !== undefined) {
      const capeMat = new THREE.MeshPhysicalMaterial({
        color: pal.cape, roughness: 0.82, metalness: 0.02,
        side: THREE.DoubleSide, sheen: 0.6,
        sheenColor: new THREE.Color(pal.capeInner ?? pal.cape),
      });
      this.mats.push(capeMat);
      this.cape = new THREE.Group();
      this.cape.position.set(0, 0.6, -0.12);
      chest.add(this.cape);

      // collar
      const collar = new THREE.Mesh(keep(new THREE.TorusGeometry(0.2, 0.036, 8, 20, Math.PI)), capeMat);
      collar.rotation.set(Math.PI / 2, 0, 0);
      collar.position.set(0, 0.04, 0.02);
      this.cape.add(collar);

      let parent: THREE.Object3D = this.cape;
      const lens = [0.3, 0.32, 0.32, 0.3, 0.26];
      const wids = [0.5, 0.62, 0.7, 0.66, 0.5];
      for (let i = 0; i < lens.length; i++) {
        const g = new THREE.Group();
        g.position.y = i === 0 ? 0 : -lens[i - 1];
        parent.add(g);
        const seg = new THREE.Mesh(keep(new THREE.PlaneGeometry(wids[i], lens[i], 3, 2)), capeMat);
        seg.position.y = -lens[i] / 2;
        g.add(seg);
        this.capeSegs.push(g);
        this.capeAng.push(0);
        parent = g;
      }
    }

    // ================= aura =================
    this.auraMat = new THREE.MeshBasicMaterial({
      color: 0xffa33c, transparent: true, opacity: 0,
      blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.BackSide,
    });
    this.aura = new THREE.Mesh(keep(new THREE.SphereGeometry(1.05, 18, 14)), this.auraMat);
    this.aura.position.y = 0.25;
    this.aura.scale.set(0.85, 1.35, 0.85);
    this.aura.visible = false;
    this.group.add(this.aura);

    this.group.scale.setScalar(scale);
    this.setPoseImmediate(POSES.idle);
  }

  /* ---------------- animation api ---------------- */

  setPoseImmediate(pose: Pose): void {
    for (const k of Object.keys(this.joints) as JointName[]) {
      const t = pose[k];
      const j = this.joints[k];
      if (t) j.rotation.set(t[0], t[1], t[2]);
      else j.rotation.set(0, 0, 0);
    }
  }

  blendPose(pose: Pose, k: number): void {
    for (const name of Object.keys(this.joints) as JointName[]) {
      const j = this.joints[name];
      const t = pose[name];
      const tx = t ? t[0] : 0, ty = t ? t[1] : 0, tz = t ? t[2] : 0;
      j.rotation.x += (tx - j.rotation.x) * k;
      j.rotation.y += (ty - j.rotation.y) * k;
      j.rotation.z += (tz - j.rotation.z) * k;
    }
  }

  /** wind flutter + idle breathing layered over the base pose */
  addFlutter(t: number, amount: number): void {
    // breathing always reads on the chest
    this.breath = Math.sin(t * 1.7) * 0.5 + 0.5;
    const b = 1 + this.breath * 0.022;
    this.chestMesh.scale.set(b, 1 + this.breath * 0.008, b);
    this.pecL.scale.set(1.15 * b, 0.86, 0.72 * b);
    this.pecR.scale.set(1.15 * b, 0.86, 0.72 * b);

    if (amount <= 0.001) return;
    const a = amount;
    this.joints.hipL.rotation.x += Math.sin(t * 8.5) * 0.1 * a;
    this.joints.hipR.rotation.x -= Math.sin(t * 8.5 + 0.6) * 0.1 * a;
    this.joints.kneeL.rotation.x += Math.sin(t * 9.2 + 1) * 0.085 * a;
    this.joints.kneeR.rotation.x += Math.sin(t * 9.2) * 0.085 * a;
    this.joints.shL.rotation.z += Math.sin(t * 6.4) * 0.045 * a;
    this.joints.shR.rotation.z -= Math.sin(t * 6.4 + 0.9) * 0.045 * a;
    this.joints.chest.rotation.y += Math.sin(t * 3.1) * 0.026 * a;
    this.joints.neck.rotation.z += Math.sin(t * 2.4) * 0.022 * a;
    this.joints.head.rotation.z += Math.sin(t * 2.9 + 0.7) * 0.018 * a;
  }

  /** turn the head toward a world point (soft, clamped) */
  lookAt(target: THREE.Vector3 | null, k: number): void {
    const head = this.joints.head;
    if (!target) {
      head.rotation.y += (0 - head.rotation.y) * k;
      return;
    }
    const local = this.group.worldToLocal(target.clone());
    const yaw = Math.atan2(local.x, Math.max(0.2, local.z));
    const clamped = Math.max(-0.6, Math.min(0.6, yaw));
    head.rotation.y += (clamped - head.rotation.y) * k;
  }

  /** 0..1 muscle flex for punches */
  setFlex(v: number): void {
    this.flex += (v - this.flex) * 0.35;
    const f = 1 + this.flex * 0.28;
    this.bicepL.scale.set(f, 1.24 * (1 + this.flex * 0.1), f);
    this.bicepR.scale.set(f, 1.24 * (1 + this.flex * 0.1), f);
  }

  setEyeGlow(color: number, intensity: number): void {
    this.eyeMat.color.setHex(color);
    this.eyeMat.emissive.setHex(color);
    this.eyeMat.emissiveIntensity = intensity;
  }

  setAura(on: boolean, color: number, strength: number): void {
    if (!this.aura || !this.auraMat) return;
    this.aura.visible = on && strength > 0.001;
    this.auraMat.color.setHex(color);
    this.auraMat.opacity = strength;
  }

  updateCape(dt: number, localSpeed: number, t: number): void {
    if (!this.cape) return;
    const target = Math.min(1.4, localSpeed * 0.022);
    for (let i = 0; i < this.capeSegs.length; i++) {
      const g = this.capeSegs[i];
      const want = target * (0.5 + i * 0.19) + Math.sin(t * 5.2 + i * 0.9) * (0.05 + target * 0.1);
      this.capeAng[i] += (want - this.capeAng[i]) * Math.min(1, dt * 7);
      g.rotation.x = this.capeAng[i];
      g.rotation.z = Math.sin(t * 3.4 + i * 0.8) * 0.055 * (0.4 + target);
      g.rotation.y = Math.sin(t * 2.2 + i * 0.5) * 0.04 * (0.3 + target);
    }
  }

  dispose(): void {
    for (const g of this.geos) g.dispose();
    for (const m of this.mats) m.dispose();
  }
}
