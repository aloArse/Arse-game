import { useEffect, useRef, useState } from "react";
import { Hand, Zap, Wind, Orbit, Flame, Move, ChevronUp, ChevronDown, Grab } from "lucide-react";
import type { Engine } from "../game3d/engine";
import { pad, touch, tap } from "../game/input";

type BtnName = "strike" | "blast" | "dash" | "slam";
const CD_BTNS: BtnName[] = ["strike", "blast", "dash", "slam"];

export default function Controls({ game }: { game: Engine }) {
  const [joy, setJoy] = useState<{ id: number; bx: number; by: number; dx: number; dy: number } | null>(null);
  const [pressed, setPressed] = useState<Record<string, boolean>>({});
  const [everUsed, setEverUsed] = useState(false);

  const ovRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const btnRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const odBtnRef = useRef<HTMLButtonElement>(null);
  const odRingRef = useRef<HTMLDivElement>(null);

  /* ---------- live cooldown painting (rAF, no react churn) ---------- */
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      const hud = game.hud;
      for (const b of CD_BTNS) {
        const ov = ovRefs.current[b];
        const el = btnRefs.current[b];
        if (!ov || !el) continue;
        const cd = hud.cds[b];
        const max = hud.cdMax[b] || 1;
        const k = Math.max(0, Math.min(1, cd / max));
        ov.style.background = k > 0.001
          ? `conic-gradient(transparent ${(1 - k) * 360}deg, rgba(4,7,18,0.8) 0deg)`
          : "none";
        ov.textContent = k > 0.03 && max > 0.5 ? cd.toFixed(1) : "";
        const cost = b === "blast" ? hud.enCost.blast : b === "dash" ? hud.enCost.dash : b === "slam" ? hud.enCost.slam : 0;
        const poor = cost > 0 && hud.en < cost;
        el.style.opacity = poor ? "0.42" : "1";
        el.style.filter = poor ? "saturate(0.35)" : "";
      }
      const od = odBtnRef.current;
      const ring = odRingRef.current;
      if (od && ring) {
        const ready = hud.od >= 100 && hud.odT <= 0;
        const active = hud.odT > 0;
        const deg = Math.max(0, Math.min(100, hud.od)) * 3.6;
        ring.style.background = `conic-gradient(${active ? "#ff5a3c" : "#ffd23f"} ${deg}deg, rgba(90,100,140,0.3) 0deg)`;
        od.classList.toggle("pulse-ready", ready);
        od.style.opacity = hud.od > 3 || active ? "1" : "0.4";
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [game]);

  useEffect(() => () => {
    pad.active = false;
    touch.blast = false; touch.strike = false; touch.up = false; touch.down = false;
  }, []);

  /* ---------- floating joystick ---------- */
  const MAXR = 62;

  const onZoneDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joy) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setEverUsed(true);
    pad.active = true;
    pad.x = 0; pad.y = 0; pad.mag = 0;
    setJoy({ id: e.pointerId, bx: e.clientX, by: e.clientY, dx: 0, dy: 0 });
  };
  const onZoneMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!joy || e.pointerId !== joy.id) return;
    let dx = e.clientX - joy.bx;
    let dy = e.clientY - joy.by;
    const len = Math.hypot(dx, dy);
    if (len > MAXR) { dx = (dx / len) * MAXR; dy = (dy / len) * MAXR; }
    pad.x = dx / MAXR;
    pad.y = dy / MAXR;
    pad.mag = Math.min(1, len / MAXR);
    setJoy({ ...joy, dx, dy });
  };
  const onZoneUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!joy || e.pointerId !== joy.id) return;
    pad.active = false;
    pad.x = 0; pad.y = 0; pad.mag = 0;
    setJoy(null);
  };

  /* ---------- buttons ---------- */
  const bind = (name: BtnName | "over" | "up" | "down" | "grab") => ({
    onPointerDown: (e: React.PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      e.stopPropagation();
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      setPressed((p) => ({ ...p, [name]: true }));
      if (name === "strike") { touch.strike = true; tap("strike"); }
      else if (name === "blast") touch.blast = true;
      else if (name === "up") touch.up = true;
      else if (name === "down") touch.down = true;
      else tap(name);
    },
    onPointerUp: () => release(name),
    onPointerCancel: () => release(name),
    onPointerLeave: (e: React.PointerEvent<HTMLButtonElement>) => {
      if (e.buttons === 0) return;
      release(name);
    },
    onContextMenu: (e: React.MouseEvent) => e.preventDefault(),
  });

  const release = (name: string) => {
    setPressed((p) => ({ ...p, [name]: false }));
    if (name === "strike") touch.strike = false;
    if (name === "blast") touch.blast = false;
    if (name === "up") touch.up = false;
    if (name === "down") touch.down = false;
  };

  const hint = (t: string) => <span className="key-hint kbd-only">{t}</span>;

  return (
    <>
      {/* ---------- joystick zone (left half) ---------- */}
      <div
        className="absolute left-0 top-0 h-full w-[46%]"
        style={{ touchAction: "none" }}
        onPointerDown={onZoneDown}
        onPointerMove={onZoneMove}
        onPointerUp={onZoneUp}
        onPointerCancel={onZoneUp}
        onContextMenu={(e) => e.preventDefault()}
      >
        {!joy && (
          <div
            className={`absolute bottom-[14%] left-[15%] flex flex-col items-center gap-2 transition-opacity duration-700 ${
              everUsed ? "opacity-0" : "opacity-60"
            }`}
          >
            <div className="joy-base relative h-[104px] w-[104px]">
              <Move className="absolute inset-0 m-auto text-indigo-200/70" size={30} />
            </div>
            <span className="font-hud text-[11px] font-bold tracking-[0.3em] text-indigo-100/80">DRAG TO FLY</span>
          </div>
        )}
        {joy && (() => {
          const len = Math.hypot(joy.dx, joy.dy);
          const mag = Math.min(1, len / MAXR);
          const ang = (Math.atan2(joy.dy, joy.dx) * 180) / Math.PI;
          return (
            <>
              <div className="joy-base" style={{ left: joy.bx - 64, top: joy.by - 64, width: 128, height: 128 }} />
              {/* thrust magnitude ring */}
              <div
                className="pointer-events-none absolute rounded-full"
                style={{
                  left: joy.bx - 64, top: joy.by - 64, width: 128, height: 128,
                  padding: 4,
                  background: `conic-gradient(from -90deg, #ffd23f ${mag * 360}deg, rgba(120,140,200,0.18) 0deg)`,
                  WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
                  WebkitMaskComposite: "xor",
                  maskComposite: "exclude",
                  opacity: 0.5 + mag * 0.5,
                }}
              />
              {/* direction pointer */}
              {mag > 0.15 && (
                <div
                  className="pointer-events-none absolute"
                  style={{
                    left: joy.bx, top: joy.by, width: 0, height: 0,
                    transform: `rotate(${ang}deg)`,
                  }}
                >
                  <div
                    style={{
                      position: "absolute", left: 44, top: -5,
                      width: 0, height: 0,
                      borderTop: "5px solid transparent",
                      borderBottom: "5px solid transparent",
                      borderLeft: `12px solid rgba(255,210,63,${0.35 + mag * 0.6})`,
                    }}
                  />
                </div>
              )}
              <div
                className="joy-knob"
                style={{ left: joy.bx - 29 + joy.dx * 0.74, top: joy.by - 29 + joy.dy * 0.74, width: 58, height: 58 }}
              />
            </>
          );
        })()}
      </div>

      {/* ---------- ability cluster ---------- */}
      <div
        className="absolute right-2 bottom-[max(0.9rem,env(safe-area-inset-bottom))] origin-bottom-right max-[560px]:scale-[0.82] max-[390px]:scale-[0.72]"
        style={{ touchAction: "none" }}
        onContextMenu={(e) => e.preventDefault()}
      >
        <div className="relative h-[266px] w-[304px]">
          {/* altitude thrusters */}
          <button
            {...bind("up")}
            aria-label="Ascend"
            className={`abtn absolute left-[6px] top-[96px] h-[58px] w-[58px] ${pressed.up ? "pressed" : ""}`}
          >
            <ChevronUp size={30} strokeWidth={3} />
            {hint("SPACE")}
          </button>
          <button
            {...bind("down")}
            aria-label="Descend"
            className={`abtn absolute left-[6px] top-[168px] h-[58px] w-[58px] ${pressed.down ? "pressed" : ""}`}
          >
            <ChevronDown size={30} strokeWidth={3} />
            {hint("C")}
          </button>

          {/* overdrive */}
          <button
            ref={odBtnRef}
            {...bind("over")}
            aria-label="Overdrive"
            className="abtn absolute right-[10px] top-0 h-[56px] w-[56px] transition-opacity"
            style={{ opacity: 0.4 }}
          >
            <div
              ref={odRingRef}
              className="absolute inset-[-3px] rounded-full"
              style={{
                padding: 3,
                WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)",
                WebkitMaskComposite: "xor",
                maskComposite: "exclude",
              }}
            />
            <Flame size={24} className="drop-shadow-[0_0_6px_rgba(255,150,40,0.8)]" />
            {hint("I")}
          </button>

          {/* grab / thunder clap */}
          <button
            {...bind("grab")}
            aria-label="Grab or thunder clap"
            className={`abtn absolute left-[92px] top-[-6px] h-[58px] w-[58px] ${pressed.grab ? "pressed" : ""}`}
          >
            <Grab size={24} />
            {hint("G")}
          </button>

          {/* slam */}
          <button
            ref={(r) => { btnRefs.current.slam = r; }}
            {...bind("slam")}
            aria-label="Nova slam"
            className={`abtn absolute left-[96px] top-[62px] h-[64px] w-[64px] ${pressed.slam ? "pressed" : ""}`}
          >
            <Orbit size={26} />
            <div ref={(r) => { ovRefs.current.slam = r; }} className="cd-sweep font-hud text-lg" />
            {hint("L")}
          </button>

          {/* dash */}
          <button
            ref={(r) => { btnRefs.current.dash = r; }}
            {...bind("dash")}
            aria-label="Sonic dash"
            className={`abtn absolute left-[84px] top-[152px] h-[66px] w-[66px] ${pressed.dash ? "pressed" : ""}`}
          >
            <Wind size={27} />
            <div ref={(r) => { ovRefs.current.dash = r; }} className="cd-sweep font-hud text-lg" />
            {hint("SHIFT")}
          </button>

          {/* blast */}
          <button
            ref={(r) => { btnRefs.current.blast = r; }}
            {...bind("blast")}
            aria-label="Plasma blast"
            className={`abtn absolute right-[6px] top-[70px] h-[66px] w-[66px] ${pressed.blast ? "pressed" : ""}`}
          >
            <Zap size={26} className="drop-shadow-[0_0_6px_rgba(255,210,63,0.7)]" />
            <div ref={(r) => { ovRefs.current.blast = r; }} className="cd-sweep font-hud text-lg" />
            {hint("K · HOLD")}
          </button>

          {/* strike */}
          <button
            ref={(r) => { btnRefs.current.strike = r; }}
            {...bind("strike")}
            aria-label="Power strike"
            className={`abtn absolute right-[2px] bottom-[2px] h-[94px] w-[94px] ${pressed.strike ? "pressed" : ""}`}
            style={{
              background:
                "radial-gradient(circle at 32% 26%, rgba(255,255,255,0.35), transparent 42%), linear-gradient(160deg, #ffd23f, #f7931e 65%, #d9432b)",
              boxShadow:
                "inset 0 0 0 2px rgba(255,255,255,0.4), inset 0 -10px 18px rgba(120,30,10,0.5), 0 8px 22px rgba(0,0,0,0.55), 0 0 24px rgba(255,160,50,0.35)",
              color: "#2b1503",
            }}
          >
            <Hand size={38} strokeWidth={2.4} />
            <div ref={(r) => { ovRefs.current.strike = r; }} className="cd-sweep font-hud text-xl" />
            {hint("J")}
          </button>
        </div>
      </div>
    </>
  );
}
